<?php
// Database settings. Create a database in Hostinger hPanel > Databases > MySQL Databases and enter it here
// (or enter it in the /setup wizard, which saves it into this file automatically).
return [
    'db_host' => 'localhost',
    'db_name' => '',
    'db_user' => '',
    'db_pass' => '',
];
